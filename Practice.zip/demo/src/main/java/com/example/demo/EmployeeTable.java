package com.example.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeTable {

	public static void main(String args[]) {

		EmployeeDetails details = new EmployeeDetails();
		List<EmployeeDetails> listEmp = new ArrayList<>();
		details.setAddress("abc.com");
		details.setName("vrajesh");
		listEmp.add(details);
		details = new EmployeeDetails();
		details.setAddress("xyz.com");
		details.setName("raju");
		listEmp.add(details);
		details = new EmployeeDetails();
		details.setAddress("123.com");
		details.setName("rajeshwar");

		listEmp.add(details);
		List<String> emailsList = listEmp.stream().map(e -> e.getAddress()).collect(Collectors.toList());
		System.out.println(emailsList);
		
		
	}

}

class EmployeeDetails {
	// Creating properties of Employee class
	int emp_id, salary;
	String name, address, department, email;

//Getter and setters for getting and setting properties  
	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//Overriding toString() method  
	@Override
	public String toString() {
		return "Employee [emp_id = " + emp_id + ", salary = " + salary + ", name = " + name + ", address = " + address
				+ ", department = " + department + ", email = " + email + "]";
	}

}
