package com.example.demo;


interface Ab {
	
	 static HelloTest test ;;
	  
	  
}

public class HelloTest implements Ab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ab ab = null;
		
		ab.test = null;
	
	}

}
