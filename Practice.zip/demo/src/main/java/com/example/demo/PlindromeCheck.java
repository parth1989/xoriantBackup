package com.example.demo;

public class PlindromeCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//String input1 ="abac";  // caba
		String input1 ="abac";  // caba
		
		int right_index = input1.length()-1;
		
		int max_count = 0;
		
		int j = right_index;
		
		for (int i=0; i<input1.length(); i++) {
			 
			for (j = right_index; j>=0; j--) {
		
			System.out.println(input1.charAt(i) +":"+input1.charAt(j));
				if (input1.charAt(i) == input1.charAt(j)) {
					max_count++;
					right_index--;
					break;
					
				}
				else {
					max_count = 0;
				}
				right_index--;
			}
			
		}
		
		System.out.println(max_count);

	}

}
