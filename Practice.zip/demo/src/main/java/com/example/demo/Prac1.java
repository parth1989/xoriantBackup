package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Prac1 {

	public static void main(String[] args) {
		
		
		List<Integer> list = Arrays.asList(1, 10, 3, 7, 5);
		int a = list.stream()
		            .peek(num -> System.out.println("will filter " + num))
		            .filter(x -> x > 5)
		            .findFirst()
		            .get();
		System.out.println(a)

		ArrayList<Integer> list = new ArrayList<Integer>();

		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);

		int sum = list.stream().map(i -> i).sum();
		
		
		

		int max_value = list.stream().max(Comparator.comparing(Integer::valueOf)).get();

		int min_value = list.stream().min(Comparator.comparing(Integer::valueOf)).get();

		System.out.println(min_value);
		System.out.println(max_value);

		// remove duplicate elements.
		Integer[] arr1 = new Integer[] { 1, 9, 8, 7, 7, 8, 9 };

		List<Integer> lista = Arrays.asList(arr1);
		lista = lista.stream().distinct().collect(Collectors.toList());
		
		System.out.println(lista);

	}

}
