package com.example.demo;

abstract class AbstractFactory {

	/*
	 * AbstractFactory(String bbb) { System.out.println("parent called"); }
	 */

}

public class Constructor extends AbstractFactory {

	public Constructor() {
		// super("d");
		System.out.println("constructor called");
	}
	
	public Constructor(String s1) {
		//super(s1);
		System.out.println("this is constructor::");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Constructor cc = new Constructor("dd");
	}

}
