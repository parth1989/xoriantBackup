package com.example.demo;

interface DemoInterface  
{   
//default method   
default void display()   
{   
System.out.println("The dispaly() method invoked");   
}   
}   
//interface without default method  
interface DemoInterface1 extends DemoInterface  
{   
	
	default void display()   
	{   
	System.out.println("The dispaly() method invoked");   
	}  
      
}   


public class InterfacePrb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
