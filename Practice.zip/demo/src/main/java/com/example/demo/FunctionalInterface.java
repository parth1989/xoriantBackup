package com.example.demo;

interface A {

	void aa();
}

interface B {
	int bb(int a, int b);
}

public class FunctionalInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = () -> System.out.println("print empty function");

		a.aa();

		B b = (c, d) -> c + d;

		int sum = b.bb(4, 5);

		System.out.println(sum);

		B b1 = (int c, int d) -> c + d;
		sum = b1.bb(6, 4);
		System.out.println(sum);

	}

}
