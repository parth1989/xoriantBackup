package com.fundamental;

// you can also use imports, for example:
 import java.util.*;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
class Customer {
    private Integer cid;
    public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	private String cname;
    private List<Order> orders;

    public void setOrders (List<Order> orders) {
     this.orders = orders;
    }

     public List<Order> getOrders () {
      return this.orders;
    }

	public Integer getOrderCount() {
		return this.orders.size();
	}
	
}

class Order {
    private Integer oid;
    private String oname;
}


public class Solution {

    public static void main(String [] args) {
        // you can write to stdout for debugging purposes, e.g.
        System.out.println("This is a debug message");
      
      List<Customer> customerList = new ArrayList<Customer>();
      Customer c1 = new Customer();
      List<Order> orderList = new ArrayList<Order>();
      Order o1 = new Order();
      Order o2 = new Order();
      Order o3 = new Order();

      orderList.add(o1); orderList.add(o2); orderList.add(o3);
     // set the orders for the customer-1
      c1.setCid(1);
       c1.setOrders(orderList);

      Customer c2 = new Customer();
      orderList = new ArrayList<Order>();
      Order o4 = new Order();
      Order o5 = new Order();
    
      orderList.add(o4); orderList.add(o5);

      // se the orders for the customer-2
        c2.setOrders(orderList); 
        c2.setCid(2);
       
      Customer c3 = new Customer();
      orderList = new ArrayList<Order>();
      Order o6 = new Order();
      Order o7 = new Order();
      Order o8 = new Order();
      Order o9 = new Order();
    
      orderList.add(o6); orderList.add(o7); orderList.add(o8);orderList.add(o9);

      // se the orders for the customer-2
        c3.setOrders(orderList);   
      c3.setCid(3);
      // add customer object into the customer list
      customerList.add(c1); customerList.add(c2); customerList.add(c3);

      long a = customerList.stream().flatMap(l-> l.getOrders().stream()).count();
      System.out.println(a);

      Optional<Entry<Customer,Integer>> finalMaxEntry= customerList.stream()
    		  .collect(Collectors.toMap(Function.identity(), e-> e.getOrders().size()))
    		  .entrySet().stream().max(Comparator.comparing(Map.Entry :: getValue));

      
      System.out.println(customerList.stream().max(Comparator.comparing(e -> e.getOrders().size())).get().getOrders().size());
      
      /*Optional<Entry<Customer,Integer>> finalMaxEntry= customerList.stream()
    		  .collect(Collectors.toMap(Function.identity(), e-> e.getOrders().size()))
    		  .entrySet().stream().max(Comparator.comparing(Map.Entry :: getValue));*/
 
      //customerList.stream().max(Comparator.comparing(e -> e.)).get();;
    
      

 
     

    


    
   //  System.out.println(count);
      

    }
}
