package com.greekforce;

import java.util.Arrays;

public class ReverseArray {

	public static void main(String[] args) {

		int a[] = { 3, 2, 1, 56, 10000, 167 };

		int right_index = a.length - 1;

		for (int i = 0; i < (a.length / 2); i++) {

			int temp = a[i];

			a[i] = a[right_index];
			a[right_index] = temp;
			right_index--;

		}
		
		System.out.println(Arrays.toString(a));

	}

}
