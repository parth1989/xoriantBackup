package com.greekforce;

import java.util.Arrays;

public class KthSmallestElement {

	public static void main(String[] args) {

		System.out.println(7/3);
		first_solution();
		second_solution();
	}

	static void second_solution() {

		int k = 3;

		//7, 3
		
		
		int a[] = { 7, 10, 4, 3, 20, 15, 2 };

		int min_value = a[0];

		for (int i = 0; i < a.length; i++) {

			if (min_value > a[i]) {
				min_value = a[i];
			}

		}

		System.out.println(min_value);

	}

	static void first_solution() {
		int k = 3;

		int a[] = { 7, 10, 4, 3, 20, 15 };

		int K_min_val = a[0];

		for (int i = 0; i < a.length; i++) {

			for (int j = i; j < a.length; j++) {
				if (a[i] > a[j]) {
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;

				}

			}

		}

		System.out.println(Arrays.toString(a));
	}

}
