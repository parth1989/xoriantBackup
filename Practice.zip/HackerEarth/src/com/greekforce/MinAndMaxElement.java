package com.greekforce;

public class MinAndMaxElement {

	public static void main(String[] args) {

		int a[] = { 3, 2, 1, 56, 10000, 167 };

		int min_val = a[0];
		int max_val = a[0];

		for (int i = 0; i < a.length; i++) {

			if (min_val > a[i])
				min_val = a[i];

			if (max_val < a[i])
				max_val = a[i];

		}
		
		System.out.println("min and max value: "+min_val +":"+max_val);

	}

}
