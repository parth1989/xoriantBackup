package com.hackerearth;

public class Tweak {

	public static void main(String[] args) {

		int ik[] = { 1, 3, 5, 7 };

		String temp[] = { "test-1", "test-2", "test-3" };

		for (int i : ik) {

		}

		for (String s : temp) {

		}

	}

}
