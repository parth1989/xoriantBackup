package com.hackerearth;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class PrintDuplicateCharacter {

	private static final int Character = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "abcabcd";

		Map<Character, Integer> map = new HashMap<Character, Integer>();

		char[] chArray = s1.toCharArray();

		for (char ch : chArray) {

			if (!map.containsKey(ch)) {

				map.put(ch, 1);
			} else {
				map.put(ch, map.get(ch) + 1);
			}
		}

	
		/*
		 * map.forEach((key, value) -> { System.out.println("Key : " + key + " Value : "
		 * + value); });
		 */

		Map<Character, Integer> collection = map.entrySet().stream().filter(x -> x.getValue() > 1)
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

		collection.forEach((key ,value) -> {
			System.out.println("Key : " + key + " Value : " + value);
		});
		
	}

}
