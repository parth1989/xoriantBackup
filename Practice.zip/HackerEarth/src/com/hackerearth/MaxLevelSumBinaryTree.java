package com.hackerearth;

public class MaxLevelSumBinaryTree {

	public int maxLevelSum(Node root) {
		
		//root.data
		
		return 0;

	}

	public static void main(String[] args) {
		

	}

}

class Node {
	int data;
	Node left, right;

	Node(int d) {
		data = d;
		left = right = null;
	}
}
