package com.hackerearth;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class UncommonCharacter {

	/*
	 * Input: str1 = �characters�, str2 = �alphabets� Output: b c l p r
	 * 
	 * Input: str1 = �geeksforgeeks�, str2 = �geeksquiz� Output: f i o q r u z
	 */
	
	static void findUnCommonChar(String s1, String s2) {
		TreeSet<Character> uncommonList = new TreeSet<>();
		
		for (char ch : s1.toCharArray()) {
			if (s2.indexOf(ch)==-1) {
				uncommonList.add(ch);
			}
		}
		
		for (char ch : s2.toCharArray()) {
			if (s1.indexOf(ch)==-1) {
				uncommonList.add(ch);
			}
		}
		
		System.out.println(uncommonList);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		findUnCommonChar("geeksforgeeks", "geeksquiz");
		findUnCommonChar("characters", "alphabets");

	}

}
