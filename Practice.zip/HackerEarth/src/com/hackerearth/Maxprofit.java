package com.hackerearth;

public class Maxprofit {

	public static void main(String[] args) {

		//int price[] = { 100, 180, 260, 310, 40, 535, 695 };
		//int price[] = { 180, 100, 260, 310, 40, 535, 695 };
		// int[] price = {3,3,5,0,0,3,1,4};
		
		//int price[] = { 260, 100, 180, 535, 40, 310, 695 };
		//int[] price = {7, 1, 5, 3, 6, 4};
		int [] price  = {50, 90, 130, 155, 20, 267, 347};

		int sum = 0;
		int max_diff = 0;
		int innerloop_length = 0;
		int price_length = price.length;

		for (int i = 0; i < price.length; i++) {

			for (int j = i + 1; j < price.length; j++) {

				if (price[i] > price[j]) {
					i = j - 1;
					break;
				}
				int temp = price[j] - price[i];
				if (temp > max_diff) {
					max_diff = temp;

				}
				innerloop_length = j + 1;

			}

			sum = sum + max_diff;
			max_diff = 0;
			if (innerloop_length == price_length)
				break;

		}

		System.out.println("maximum profit of shares: " + sum);

	}

}
