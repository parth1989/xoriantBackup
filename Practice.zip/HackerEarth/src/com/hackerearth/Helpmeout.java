package com.hackerearth;
import java.util.*;

//https://www.hackerearth.com/practice/data-structures/arrays/1-d/practice-problems/algorithm/solve-friends-problem/description/

class Helpmeout {
    public static void main(String args[] ) throws Exception {
        Scanner s = new Scanner(System.in);

        List<Integer> list = new ArrayList<Integer>();
        
        int moves = 0;

        int value = s.nextInt();

        for (int i=0; i< value; i++) {
           list.add(s.nextInt());
        }
    
        boolean result = false;
        boolean findEven = false;

        while (!result) {
            
       // decrement array element by 1
         for (int i = 0; i<value; i++) {
             int temp = list.get(i);
            
             if (temp % 2 != 0) {
                 temp = temp - 1 ;
                 list.set(i,temp);
                 moves++;
             } 
             
         }
        
        for (int k =0; k<value; k++) {
            if (list.get(k)!=0) {
                result = false;
                break;
            } else {
                result = true;
            }
        }
        if (!result)
            moves++;
        
        // half value in half operation 
        for (int l =0; l<value; l++) {
            int even_value = 0;
            even_value = list.get(l)/2;
            list.set(l, even_value);
        }
     }

     System.out.println(moves);
    }
}
