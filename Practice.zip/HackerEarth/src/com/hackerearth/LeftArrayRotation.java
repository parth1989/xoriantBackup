package com.hackerearth;

import java.util.Arrays;

public class LeftArrayRotation {

	static void leftRotate(int arr[], int d, int n) {

		int i = 0;

		int tempArray[] = new int[d];

		for (int b = 0; b < d; b++) {
			tempArray[b] = arr[b];

		}

		for (int a = d; a < arr.length; a++) {

			arr[i] = arr[a];
			i++;
		}

		for (int k = 0; k < tempArray.length; k++) {
			arr[i] = tempArray[k];
			i++;
		}

		System.out.println(Arrays.toString(arr));
	}

	static void secondRotate(int arr[], int d, int n) {

		int i = 0;

		int tempArray[] = new int[d];

		for (int b = 0; b < d; b++) {
			tempArray[b] = arr[b];

		}

		for (int a = d; a < arr.length; a++) {

			arr[i] = arr[a];
			i++;
		}

		for (int k = 0; k < tempArray.length; k++) {
			arr[i] = tempArray[k];
			i++;
		}

		System.out.println(Arrays.toString(arr));
	}

	public static void main(String[] args) {
		 leftRotate(new int[] { 1, 2, 3, 4, 5, 6, 7 }, 2, 7);
	//	secondRotate(new int[] { 1, 2, 3, 4, 5, 6, 7 }, 2, 7);
		//secondRotate(new int[] { 1, 2, 3, 4, 5 }, 2,5);
		//thirdRotate(new int[] { 1, 2, 3, 4, 5, 6, 7 }, 2, 7);  // 3,4,5,6,7,1,2
	}
	
	static void thirdRotate(int arr[], int left_rotate, int n) {
		
		int right_index = n-1;
		
		for (int i =0; i<left_rotate; i++) {
			
			int temp = arr[i];
			arr[right_index] = arr[i];
			
			
			
		}
		
	}

}
