package com.hackerearth;

public class Minsumation {

	public static void main(String[] args) {

		int a[] = new int[] { 5, 19, 7, 2, 3, 12, 1, 4 };

		int min_val = a[0];
		int secon_val = a[0];

		for (int i = 0; i < a.length; i++) {

			if (min_val > a[i]) {
				secon_val = min_val;
				min_val = a[i];

			}

			if (secon_val > a[i] && a[i] != min_val) {
				secon_val = a[i];
			}

		}

		System.out.println("first:"+ min_val+",second: "+secon_val);
	}

}
