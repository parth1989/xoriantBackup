package com.hackerearth;

public class SecondMax {

	public static void main(String[] args) {

		

		int a[] = new int [] {2,4,5,1,3,15,25,89,27,26};
		
		int max = 0;
		int second_max =0;
		
		for (int i = 0; i<a.length; i++) {
			
		if (max < a[i]) {
				second_max = max;
				max = a[i];
			}
			
			
		}
		
		System.out.println(second_max);

	}

}
