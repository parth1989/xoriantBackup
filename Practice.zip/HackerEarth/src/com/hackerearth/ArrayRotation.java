package com.hackerearth;

import java.util.Arrays;

public class ArrayRotation {

	public static void main(String[] args) {
		
		

		int a[] = new int[] { 1, 2, 3, 4, 5, 6};

		System.out.println(a.length/2);
		int right_index = a.length - 1;

		for (int i = 0; i < a.length/2; i++) {

			int temp = a[i];
			a[i] = a[right_index - i];
			a[right_index-i]= temp;

		}
		
		System.out.println(Arrays.toString(a));
	}

}
