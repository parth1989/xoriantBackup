package com.hackerearth;

import java.util.*;
//https://www.hackerearth.com/practice/data-structures/arrays/1-d/practice-problems/algorithm/micro-and-array-update/submissions/
class MicroArrayUpdate {

   private static void findSteps(Scanner s) {
       int n = s.nextInt();
       int k = s.nextInt();

      
       int min_value = -1;

       for (int i = 0; i<n; i++) {
           int temp = s.nextInt();
           if (min_value == -1)
              min_value = temp;
           else if (min_value > temp) {
                min_value = temp;
           }   
       }

         int steps = k - min_value;

         if (steps >= 0)
         System.out.println(steps);
         else 
         System.out.println(0);
   }
    
    public static void main(String args[] ) throws Exception {
        //Scanner
        Scanner s = new Scanner(System.in);
        

        int test_cases = s.nextInt();

        for (int i = 0; i< test_cases; i++) {

            findSteps(s);
        }

    }
}
