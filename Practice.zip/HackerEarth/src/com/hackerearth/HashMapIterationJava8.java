package com.hackerearth;

import java.util.HashMap;
import java.util.Map;

public class HashMapIterationJava8 {

	public static void iterateUsingKeySetAndForeach(Map<String, String> map) {
	    for (String key : map.keySet()) {
	        System.out.println(key + ":" + map.get(key));
	    }
	    
	    for (String key : map.values()) {
	        System.out.println(key + ":" + map.get(key));
	    }
	}
	
	public static void main(String[] args) {
		
		 
		Map<String, String> map = new HashMap();
		
		map.put("test", "abc");
		iterateUsingKeySetAndForeach(map);
		
		
		
      
	}

}
