package com.hackerearth;

import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayPrac {

	public static void main(String[] args) {
		
		CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
		
		list.add("a");
		list.add("b");
		list.add("c");
		
		
		list.remove(0);
		
		System.out.println(list.get(0));
		
		list.remove(0);
		
		System.out.println(list.get(0));
		
	}

}
