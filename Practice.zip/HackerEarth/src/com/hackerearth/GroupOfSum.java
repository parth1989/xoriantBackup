package com.hackerearth;

import java.util.ArrayList;
import java.util.List;

public class GroupOfSum {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>();
		int[] numbers = new int[] { 1, 4, 8, 10, 12, 14, 16, 18, 20, 22, 23 };
		int sum = 0;
		int group_count = 3;

		for (int i = 0; i < numbers.length; i++) {

			if ((i + group_count) > numbers.length) {
				break;
			}

			for (int j = 0; j < group_count; j++) {

				sum = sum + numbers[i + j];
			}
			System.out.println(sum);
			sum = 0;
		}
	}

}
