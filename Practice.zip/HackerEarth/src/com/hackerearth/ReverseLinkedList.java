package com.hackerearth;
 class ListNode {
	int val;
	ListNode next;

	ListNode() {
	}

	ListNode(int val) {
		this.val = val;
	}

	ListNode(int val, ListNode next) {
		this.val = val;
		this.next = next;
	}
}

class ReverseLinkedList {
	static int size = 1;

	public ListNode reverseList(ListNode head) {

		ListNode node = head;

		ListNode tail = null;

		ListNode reverseNodeList = new ListNode();

		tail = reverseNodeList;
		for (int i = 0; i < size; i++) {

			ListNode temp_node = null;
			for (int j = (size - i); j > 0; j--) {

				temp_node = node;
				node = node.next;

			}

			reverseNodeList.val = temp_node.val;
			if ((size - 1) > i) {
				reverseNodeList.next = new ListNode();

			}
			reverseNodeList = reverseNodeList.next;
			node = head;

		}
		return tail;
	}

	public static void main(String[] args) {

		ReverseLinkedList solution = new ReverseLinkedList();
		ListNode head;
		ListNode node = new ListNode(1);
		head = node;
		for (int i = 2; i < 6; i++) {

			node.next = new ListNode(i);
			node = node.next;
			size++;
		}

		solution.reverseList(head);
	}
}