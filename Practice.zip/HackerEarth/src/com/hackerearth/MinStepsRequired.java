package com.hackerearth;

public class MinStepsRequired {

	static int perform1(String str) {

		char prev_char = 'z';

		int a_steps = 0;
		int b_steps = 0;

		for (char ch : str.toCharArray()) {

			if (ch == 'a') {

				if (prev_char != ch) {
					a_steps++;
				}
			}
			if (ch == 'b') {

				if (prev_char != ch) {
					b_steps++;
				}
			}

			prev_char = ch;
		}

		if (a_steps < b_steps)
			return a_steps + 1;
		if (a_steps > b_steps)
			return b_steps + 1;
		if (a_steps == b_steps)
			return a_steps + 1;

		return 0;
	}

	static int minSteps(String str) {

		return perform1(str);

	}

	public static void main(String[] args) {

		System.out.println(minSteps("babababaaaaabb"));
		System.out.println(minSteps("bbaaabb"));
		System.out.println(minSteps("aababaa"));
		System.out.println(minSteps("aabbaabb"));
		System.out.println(minSteps("aaabbb"));
		System.out.println(minSteps("abababab"));
		System.out.println(minSteps("bbbbbbbbba"));

	}

}
