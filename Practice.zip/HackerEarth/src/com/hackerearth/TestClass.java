package com.hackerearth;
/* IMPORTANT: Multiple classes and nested static classes are supported */
import java.io.BufferedReader;
import java.io.InputStreamReader;

//import for Scanner and other utility classes
import java.util.*;


// Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail

class TestClass {
    public static void main(String args[] ) throws Exception {
        
        Scanner s = new Scanner(System.in);
        s.nextInt()
        String name = s.nextLine();  
        s.next
        System.out.println("Hi, " + name + ".");    

    }
}
