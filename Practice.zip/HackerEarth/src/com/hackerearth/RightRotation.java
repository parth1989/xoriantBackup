package com.hackerearth;

import java.util.Arrays;

public class RightRotation {

	static void rotation(int a[], int rotation_steps) {

		int right_index = a.length - 1;

		for (int k = 0; k < rotation_steps; k++) {

			for (int i = 0; i < a.length; i++) {

				int temp = a[i];
				a[i] = a[right_index];
				a[right_index] = temp;
			    System.out.println(Arrays.toString(a));
			}
		}

		System.out.println(Arrays.toString(a));
	}
	
	static void rotation1(int a[], int rotation_steps) {

		int right_index = a.length - 1;
		
		
		int temp_array [] = new int[right_index];
		
	//	for (int i=right_index-1; i< )
             
		

		System.out.println(Arrays.toString(a));
	}

	public static void main(String[] args) {

		rotation(new int[] { 1, 2, 3, 4, 5 }, 2);
	}

}
