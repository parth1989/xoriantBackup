package com.hackerearth;

public class MaxProfit1 {

	public static void main(String[] args) {

		// int price[] = { 100, 180, 260, 310, 40, 535, 695 };
		// int price[] = { 180, 100, 260, 310, 40, 535, 695 };
		// int[] price = {3,3,5,0,0,3,1,4};

		// int[] price = { 3, 2, 1, 0 };
		// int[] price = {7, 1, 5, 3, 6, 4};
		int[] price = { 7, 6, 3, 2, 1 };

		// int price[] = { 260, 100, 180, 535, 40, 310, 695 };

		int sum = 0;
		int max_diff = 0;
		int price_length = price.length;
		int i, j = 0;

		for (i = 0; i < price.length; i++) {

			for (j = i + 1; j < price.length; j++) {

				if (price[i] > price[j] || price[j] < price[j - 1]) {
					i = j - 1;
					break;
				}
				int temp = price[j] - price[i];
				if (temp > max_diff) {
					max_diff = temp;

				}

			}

			sum = sum + max_diff;
			max_diff = 0;
			if (j == price_length)
				break;

		}

		System.out.println("maximum profit of shares: " + sum);

	}

}
