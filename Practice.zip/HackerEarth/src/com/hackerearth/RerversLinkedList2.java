package com.hackerearth;

public class RerversLinkedList2 {

	public static ListNode reverseList(ListNode head) {

		ListNode node = head;
		ListNode node2 = head.next;

		ListNode outer_node = head;

		ListNode reverseNode = new ListNode();

		ListNode tail = new ListNode();

		tail = reverseNode;

		do {
			while (node2.next != null) {

				node = node.next;
				node2 = node2.next;
			}

			reverseNode.val = node2.val;
			reverseNode.next = new ListNode();
			reverseNode = reverseNode.next;

			node.next = null;
			node = head;
			node2 = head.next;
		} while (outer_node.next != null);

		reverseNode.val = outer_node.val;
		return tail;

	}

	public static void main(String[] args) {

		ListNode head;
		ListNode node = new ListNode(1);
		head = node;
		for (int i = 2; i < 3; i++) {
			node.next = new ListNode(i);
			node = node.next;
		}

		reverseList(head);
	}

}
