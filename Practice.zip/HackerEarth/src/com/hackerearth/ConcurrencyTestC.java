package com.hackerearth;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrencyTestC {

	public static void main(final String[] args) {
		final Tester tester = new Tester();
		tester.test();
		//tester.test1();

	}

}

class Tester {
	public void test() {
		final ExecutorService executor = Executors.newFixedThreadPool(2);
		final ReentrantLock reentrantLock = new ReentrantLock();
		executor.submit(() -> {
			reentrantLock.lock();
			try {
				System.out.println("*1");
				System.out.println("*1");
			}  finally {
				System.out.println("enter-1");
				reentrantLock.unlock();
			}
		});

		executor.submit(() -> {
			System.out.println("Locked: " + reentrantLock.isLocked());
			System.out.println("Held by me: " + reentrantLock.isHeldByCurrentThread());
			final boolean locked = reentrantLock.tryLock();
			System.out.println("Lock acquired: " + locked);
		});

	}
	
	public void test1() {
		final ExecutorService executor = Executors.newFixedThreadPool(2);
		final ReentrantLock reentrantLock = new ReentrantLock();
		executor.submit(() -> {
			reentrantLock.lock();
			try {
				System.out.println("*1");
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("*1");
			}  finally {
				System.out.println("enter-1");
				reentrantLock.unlock();
			}
		});

		executor.submit(() -> {
			System.out.println("Locked: " + reentrantLock.isLocked());
			System.out.println("Held by me: " + reentrantLock.isHeldByCurrentThread());
			final boolean locked = reentrantLock.tryLock();
			System.out.println("Lock acquired: " + locked);
		});

	}

}
