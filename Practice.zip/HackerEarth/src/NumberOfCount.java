

public class NumberOfCount {

	public static void main(String[] args) {

		System.out.println("a"+"b"+"c");
		String s1 = "mmmmmmmmmmmmmmmmmmmmm uuuuuuuumbaaaiii";
		int count = 0;
		String maxValue = "0:0";
  
		
		boolean isCharExists = true;
		int fromIndex = 0;

		for (char ch : s1.toCharArray()) {

			while (isCharExists) {
				if (s1.indexOf(ch, fromIndex) != -1) {
					count++;
					fromIndex = s1.indexOf(ch, fromIndex) + 1;
				} else {
					isCharExists = false;
				}
			}
			
			if (!maxValue.isEmpty() && (Integer.parseInt(maxValue.split(":")[1]) < count) )
			maxValue = ch+":"+count;
			
			count = 0;
			fromIndex= 0;
			isCharExists = true;
		}
		
		System.out.println(maxValue);

	}

}
