package java.practice.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JavaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		List <String> words = Arrays.asList("Oracle", "Magazine", "Java");
		
	List wordList = words.stream().skip(1).limit(2).filter(word->word.length()<7).map(String::toString).collect(Collectors.toList());
	
	System.out.println(wordList);
		

	}

}
