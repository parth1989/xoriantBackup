import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class TwoOutOfThree {
	
	public static void main (String args[])  {
		
		Integer aArray[] = new Integer[] {56, 56, 34, 34, 72, 71};
		ArrayList<Integer> A = new ArrayList<Integer>(aArray.length);
		
		for (int i : aArray) {
			A.add(i);
		}
		
		Integer bArray[] = new Integer[] {56, 56, 34, 34, 72, 71};
		ArrayList<Integer> B = new ArrayList<Integer>(bArray.length);
		
		for (int i : bArray) {
			B.add(i);
		}
		
		Integer cArray[] = new Integer[] {56, 56, 34, 34, 72, 71};
		ArrayList<Integer> C = new ArrayList<Integer>(cArray.length);
		
		for (int i : cArray) {
			C.add(i);
		}
		
		
		System.out.println(solve(A, B, C));
	}
	
	public static ArrayList<Integer> solve(ArrayList<Integer> A, ArrayList<Integer> B, ArrayList<Integer> C) {

		Set<Integer> set = new HashSet<>(A);

		ArrayList<Integer> commonList = new ArrayList<>();

		for (Integer b : B) {
			boolean result = set.add(b);
			if (!result)
				if (!commonList.contains(b)) commonList.add(b);
		}

		for (Integer c : C) {
			boolean result = set.add(c);
			if (!result)
				if (!commonList.contains(c)) commonList.add(c);
		}

		Collections.sort(commonList);
		return commonList;
	}

}
