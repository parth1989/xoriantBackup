import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.graalvm.compiler.phases.common.RemoveValueProxyPhase;

public class PairingCombination {
	
	
	public static void solution(int a[]) {
		
		int[] result = new int[a.length]; // 5, 16,7,13,22 // 7
		Arrays.sort(a);
		result[0] = a[0];

		List<Integer> even_list = new ArrayList();
		List<Integer> odd_list = new ArrayList();

		for (int i = 0; i < a.length; i++) {

			if (a[i] % 2 == 0) {
				even_list.add(a[i]);
			} else {
				odd_list.add(a[i]);
			}
		}
		
		if (a[0] % 2 != 0) { 
			odd_list.remove(0);
		}
		else 
			even_list.remove(0);
		

		
		int even_index = 0, odd_index = 0;
		boolean isOdd = false;
		if (a[0] % 2 != 0) {
			isOdd = true;
			
		} 		
			for (int i = 1; i < a.length; i++) {

				if (isOdd && (even_list.size() > even_index) || odd_list.isEmpty()) {

					result[i] = even_list.get(even_index);
					even_index++;
					isOdd = false;
				}

				else if (!isOdd && (odd_list.size() > odd_index) || even_list.isEmpty()) {
                	result[i] = odd_list.get(odd_index);
					odd_index++;
					isOdd = true;
				}

				
				
				  if (even_list.size() == even_index) isOdd = false;
				  if (odd_list.size() == odd_index) isOdd = true;
				 
			}

		
		
		System.out.println(Arrays.toString(result));


		
	}

	public static void main(String[] args) {

		// 1,3,5,2,4 op: 1,2,3,4,5

		int[] input1 = new int[] { 5, 16,7,13,22 }; // 5, 16,7,13,22 // 7
	    int [] input2 = new int[] { 4,7,5,6,3,1}; 
	    int [] input3 = new int[] { 4,7,5,6,3,2}; 
	    //int [] input4 = new int[] { 4,6,8,10,12,14}; 
	    int [] input4 = new int[] { 4,6,8,10,12,14,16}; 
		
		/*
		 * solution(input1); solution(input2); solution(input3);
		 */
        solution(input4);
		  
	}

}
