import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HelloWorld {

	static void m1() {
		System.out.println("llalal");
	}

	public static void main(String[] args) {
		
		int d = 123;
		
		
		ArrayList<Integer> intg=null;
		
		
		HashMap<Integer, Object> map = new HashMap<>();
		map.put(d, 4);

		 String[] words = { "cool", "lock", "cook" }; // Output: ["c","o"]
		//String[] words = { "bella", "label", "roller" };
		Set<Character> setList = new HashSet<Character>();

		boolean isUnique = false;

		for (char ch : words[0].toCharArray()) {

			for (String word : words) {
				if (word.indexOf(ch) == -1) {
					isUnique = false;
					break;
				} else {
					isUnique = true;
					continue;
				}
			}
			if (isUnique)
				setList.add(ch);

		}
		System.out.println("unique character set:: " + setList);

	}

}
