

import java.util.HashSet;
import java.util.Set;

public class JavaTest implements Runnable{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
Thread t=new Thread(new JavaTest());
t.start();
System.out.println("Started");
t.join();
System.out.println("Complete..");
	}

	@Override
	public void run() {
		for(int i=0;i<4;i++)
		{
			System.out.println(i);
		}
		
	}

}
