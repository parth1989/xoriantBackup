import java.util.ArrayList;

public class Leftarray {

	// A : [ 93, 43, 68, 47, 80, 65, 92, 4, 82, 46, 35, 67, 65, 90, 91, 45, 92, 84,
	// 89, 45, 21, 60, 61, 100, 90, 56, 30, 42, 21, 74, 43, 24, 44, 51, 22, 1 ]
	// B : [ 58, 76, 14, 8, 100, 95, 50, 83, 58, 81, 84, 19, 45, 11, 10, 62, 82, 82,
	// 28, 36, 67, 71, 44, 29, 54, 1, 87, 4, 78 ]

	public static void main(String args[]) {

		Leftarray sl = new Leftarray();

		Integer aArray[] = new Integer[] { 6, 31, 33, 13, 82, 66, 9, 12, 69, 21, 17, 2, 50, 69, 90, 71, 31, 1, 13, 70, 94, 46, 89, 13, 55, 54, 67, 97, 28, 27, 62, 34, 41, 18, 15, 35, 13, 84, 93, 27, 89, 23, 6, 56, 94, 40, 54, 95, 47 };
		ArrayList<Integer> A = new ArrayList<Integer>(aArray.length);
		for (int i : aArray) {
			A.add(i);
		}

		Integer bArray[] = new Integer[] { 88, 85, 98, 36, 66, 40, 30, 26, 51, 77, 62, 60, 92, 64, 53, 86, 24, 53, 85, 49, 57, 29, 32, 60, 75, 82, 17, 23, 67, 51, 23, 11, 70, 59 };
		ArrayList<Integer> B = new ArrayList<Integer>(bArray.length);
		for (int i : bArray) {
			B.add(i);
		}

		ArrayList<ArrayList<Integer>> result  = sl.solve(A, B);
		
		System.out.println(result);
	}

	public ArrayList<ArrayList<Integer>> solve(ArrayList<Integer> A, ArrayList<Integer> B) {

		ArrayList<ArrayList<Integer>> resultList = new ArrayList<ArrayList<Integer>>();

		for (Integer b : B) {

			Integer numberOfRotation = numberOfRotation(A.size(), b);
			System.out.println(numberOfRotation);
			if (numberOfRotation > 0) {

				ArrayList<Integer> subList = new ArrayList<Integer>();
			
				int index = 0;

				for (int i = numberOfRotation; i < A.size(); i++) {
					subList.add(index, A.get(i));
					index++;
				}

				for (int i = 0; i < numberOfRotation; i++) {
					subList.add(A.get(i));
				}

				resultList.add(subList);
			}
			else {
				resultList.add(A);
			}

		}
		return resultList;

	}

	public Integer numberOfRotation(Integer a, Integer b) {
		if (b > a) {
			return b % a;
		}
		return b;
	}
}
