import java.util.ArrayList;
import java.util.List;

public class ImmutableString {

	public static void main(String[] args) {
		
		String s1 ="Java";
		
		String s2 = s1;
		
		System.out.println(s1==s2);
		
		s1 = "Python";
		
		
		
		System.out.println(s1==s2);
		
		List<String> list = new ArrayList<>();
		
		list.add("abc");
		
		List<String> list2 = list;
		
		System.out.println(list == list2);

		list.add("xyzzz");
		
		System.out.println(list == list2);
		
		list = null;
		
		System.out.println(list2);
		System.out.println(list);
		
		System.out.println(list2);
		
		
	}

}
