import java.util.function.Predicate;

public class _Predicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Predicate<String> isPhoneNumberValid = phoneNumber -> phoneNumber.length()>0;
		
		boolean result  = isPhoneNumberValid.test("124");
		System.out.println(result);
	}

}
