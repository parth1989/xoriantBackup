import java.util.function.Function;

public class _Function {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Function<Integer, Integer> incrementByOneFunction = d -> d + 1;

		int increment = incrementByOneFunction.apply(1);
		System.out.println(increment);
		
		// combined function
		
		Function<Integer, Integer> multipleBy10Function = number -> number * 10;
		
		Function<Integer, Integer> incrementThenMultiply = 	incrementByOneFunction.andThen(multipleBy10Function);
		
		Integer combinedResult = incrementThenMultiply.apply(1);
		System.out.println(combinedResult);
		
	}

}
