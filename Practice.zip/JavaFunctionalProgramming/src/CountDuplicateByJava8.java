import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CountDuplicateByJava8 {

	public static <T> Map<T, Long> countByStreamGroupBy(List<T> inputList) {
	    return inputList.stream().collect(Collectors.groupingBy(k -> k, Collectors.counting()));
	    
	    //inputList.stream().collect(Collectors.gr)
	}
	
	public static void main (String args[]) {
		
		List<String> abc = new ArrayList();
		abc.add("a");
		abc.add("b");
		abc.add("c");
		abc.add("a");
		abc.add("b");
		
		System.out.println(countByStreamGroupBy(abc));
	}
}
