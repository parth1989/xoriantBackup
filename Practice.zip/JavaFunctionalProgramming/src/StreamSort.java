import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StreamSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Person> persons = getPeople();

		List<Person> resultPersons = persons.stream().sorted(Comparator.comparing(Person::getAge))
				.collect(Collectors.toList());

		resultPersons.stream().map(Person::getName).forEach(System.out::println);

		boolean result = resultPersons.stream().anyMatch(p -> p.getGender().equalsIgnoreCase("FEMALE"));
		System.out.println("result of anymatch:"+result);

	}

	private static List<Person> getPeople() {

		return List.of(new Person("James Bond", 20, Gender.MALE), new Person("Alina Smith", 33, Gender.FEMALE),
				new Person("Helena White", 57, Gender.FEMALE), new Person("Alex Boz", 14, Gender.MALE),
				new Person("Jamie Goa", 99, Gender.MALE), new Person("Anna Cook", 7, Gender.FEMALE),
				new Person("Zelda Brown", 120, Gender.FEMALE));

	}

}

class Gender {

	static String MALE = "male";
	static String FEMALE = "female";
}

class Person {

	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	int age;
	String gender;

	Person(String name, int age, String gender) {

		this.name = name;
		this.age = age;
		this.gender = gender;
	}

}
