interface MyInterface1 {
	public static int num = 100;

	public default  void display() {
		System.out.println("display method of MyInterface1");
	}
}

interface MyInterface3 extends MyInterface1 {
	public static int num = 1000;

	public default void display1() {
		System.out.println("display method of MyInterface2");
	}
}


interface MyInterface2 {
	public static int num = 1000;

	public default void display() {
		System.out.println("display method of MyInterface2");
	}
}

public class InterfaceExample implements MyInterface1, MyInterface3 {
	public void display() {
		//MyInterface1.super.display();
		// or,
		MyInterface3.super.display1();
	}

	public static void main(String args[]) {
		InterfaceExample obj = new InterfaceExample();
		obj.display();
	}
}
